import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from database import SessionLocal
from models import User


# Connect to the database and get the first 10 users
db = SessionLocal()

users = db.query(User).limit(10).all()


# Extract ZIP code and state from the address
def parse_address(address):
    parts = address.split()

    zip_code = parts[-1]
    state = parts[-2]

    return zip_code, state


# Test how the address parser works
address = "93385 Jill Spring\nPort Stephanieburgh, MS 79321"

zip_code, state = parse_address(address)

print("ZIP:", zip_code)
print("State:", state)


# Test the parser on users from the database
for user in users:
    zip_code, state = parse_address(user.address)
    print(user.address, "->", zip_code, state)

db.close()


# Create a mapping between states and their indices
states = ["MD", "NY", "CA", "MD", "CA"]

unique_states = sorted(set(states))

state_to_index = {
    state: i
    for i, state in enumerate(unique_states)
}

print(state_to_index)


# Get all users for the dataset
db = SessionLocal()

users = db.query(User).all()


# Get all states and create their indices
states = [parse_address(user.address)[1] for user in users]
unique_states = sorted(set(states))

state_to_index = {
    state: i
    for i, state in enumerate(unique_states)
}


# Create features X and target values y
X = []
y = []

for user in users:
    zip_code, state = parse_address(user.address)

    X.append(float(zip_code))
    y.append(state_to_index[state])

print("X:", X[:10])
print("y:", y[:10])


# Create a custom Dataset
class PetDataset(Dataset):
    def __init__(self, X, y):
        self.X = torch.tensor(X, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return self.X[index].unsqueeze(0), self.y[index]


# Create the dataset
dataset = PetDataset(X, y)

print(len(dataset))
print(dataset[0])


# Split the dataset into training and test sets
train_size = int(0.8 * len(dataset))
test_size = len(dataset) - train_size

train_dataset, test_dataset = random_split(
    dataset,
    [train_size, test_size]
)

print("Train:", len(train_dataset))
print("Test:", len(test_dataset))


# Create DataLoaders to get data in batches
train_loader = DataLoader(
    train_dataset,
    batch_size=32,
    shuffle=True
)

test_loader = DataLoader(
    test_dataset,
    batch_size=32,
    shuffle=False
)


# Get the first batch and check it
X_batch, y_batch = next(iter(train_loader))

print("X batch:", X_batch)
print("y batch:", y_batch)
print("Batch size:", len(X_batch))


# Get the number of classes
num_classes = len(unique_states)

print("Number of classes:", num_classes)


# Create a model for state classification
class StateModel(nn.Module):
    def __init__(self, num_classes):
        super().__init__()

        self.linear = nn.Linear(1, num_classes)

    def forward(self, x):
        return self.linear(x)


# Create the model
model = StateModel(num_classes)


# Test the model on one object
x = torch.tensor([[34627.0]])

output = model(x)

print("Output:", output)
print("Shape:", output.shape)


# Select the class with the highest value
predicted_class = output.argmax(dim=1)

print("Predicted class:", predicted_class)


# Create a reverse mapping from index to state
index_to_state = {
    i: state
    for i, state in enumerate(unique_states)
}


# Convert the predicted index back to the state name
predicted_state = index_to_state[predicted_class.item()]

print("Predicted state:", predicted_state)


# Create a loss function for classification
loss_fn = nn.CrossEntropyLoss()


# Set the correct class for our object
y = torch.tensor([12])


# Calculate the model's loss
loss = loss_fn(output, y)

print("Loss:", loss)


# Calculate the gradients of the model parameters
loss.backward()

print("Weight gradient:", model.linear.weight.grad)
print("Bias gradient:", model.linear.bias.grad)



optimizer = torch.optim.SGD(
    model.parameters(),
    lr=0.001
)

for epoch in range(10):

    for X_batch, y_batch in train_loader:

        optimizer.zero_grad()
        output = model(X_batch)
        loss = loss_fn(output, y_batch)
        loss.backward()
        optimizer.step()

    print("Epoch:", epoch + 1, "Loss:", loss.item())

optimizer.step()

print("Weight before:", model.linear.weight[12].item())
print("Bias before:", model.linear.bias[12].item())

optimizer.step()

output_after = model(x)

print("Output after:", output_after)

predicted_class_after = output_after.argmax(dim=1)

print("Predicted class after:", predicted_class_after)

predicted_state_after = index_to_state[predicted_class_after.item()]

print("Predicted state after:", predicted_state_after)

print("Weight after:", model.linear.weight[12].item())
print("Bias after:", model.linear.bias[12].item())

